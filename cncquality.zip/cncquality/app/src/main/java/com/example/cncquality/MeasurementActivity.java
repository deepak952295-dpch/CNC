package com.example.cncquality;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MeasurementActivity extends AppCompatActivity {

    Spinner productSpinner;
    TextView selectedProductText, submitMessage, qualityMeasurementsLabel;
    LinearLayout dimensionContainer;
    Button submitMeasurementsBtn;

    // Inputs
    EditText flangeOuterDiaInput, flangeThicknessInput, outerCollarDiaInput,
            radiusInput, surfaceRoughnessInput, perpendicularityInput,
            lengthFEInput, chamferLengthInput, angleInput;

    // Labels
    TextView perpendicularityLabel, lengthFELabel, chamferLengthLabel, angleLabel;

    // Connection Type
    String connectionType = "MACHINE_OPERATOR"; // default

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_measurement);

        // Initialize views
        productSpinner = findViewById(R.id.productSpinner);
        selectedProductText = findViewById(R.id.selectedProductText);
        submitMessage = findViewById(R.id.submitMessage);
        qualityMeasurementsLabel = findViewById(R.id.qualityMeasurementsLabel);
        dimensionContainer = findViewById(R.id.dimensionContainer);
        submitMeasurementsBtn = findViewById(R.id.submitMeasurementsBtn);

        flangeOuterDiaInput = findViewById(R.id.flangeOuterDiaInput);
        flangeThicknessInput = findViewById(R.id.flangeThicknessInput);
        outerCollarDiaInput = findViewById(R.id.outerCollarDiaInput);
        radiusInput = findViewById(R.id.radiusInput);
        surfaceRoughnessInput = findViewById(R.id.surfaceRoughnessInput);
        perpendicularityInput = findViewById(R.id.perpendicularityInput);
        lengthFEInput = findViewById(R.id.lengthFEInput);
        chamferLengthInput = findViewById(R.id.chamferLengthInput);
        angleInput = findViewById(R.id.angleInput);

        perpendicularityLabel = findViewById(R.id.perpendicularityLabel);
        lengthFELabel = findViewById(R.id.lengthFELabel);
        chamferLengthLabel = findViewById(R.id.chamferLengthLabel);
        angleLabel = findViewById(R.id.angleLabel);

        // Setup spinner (original UI)
        String[] products = {"Select Product", "VOLVO"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, products);
        productSpinner.setAdapter(adapter);

        productSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                String selected = parent.getItemAtPosition(position).toString();
                if (!selected.equals("Select Product")) {
                    selectedProductText.setText("Selected Product: " + selected);
                    dimensionContainer.setVisibility(View.VISIBLE);
                    submitMeasurementsBtn.setVisibility(View.VISIBLE);
                    qualityMeasurementsLabel.setVisibility(View.VISIBLE);
                } else {
                    dimensionContainer.setVisibility(View.GONE);
                    submitMeasurementsBtn.setVisibility(View.GONE);
                    qualityMeasurementsLabel.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });

        updateDimensionVisibility();

        // Submit button click → save to history
        submitMeasurementsBtn.setOnClickListener(v -> validateAndSubmit());
    }

    private void updateDimensionVisibility() {
        if ("MACHINE_OPERATOR".equals(connectionType)) {
            perpendicularityInput.setVisibility(View.GONE);
            perpendicularityLabel.setVisibility(View.GONE);
            lengthFEInput.setVisibility(View.GONE);
            lengthFELabel.setVisibility(View.GONE);
            chamferLengthInput.setVisibility(View.GONE);
            chamferLengthLabel.setVisibility(View.GONE);
            angleInput.setVisibility(View.GONE);
            angleLabel.setVisibility(View.GONE);
        } else if ("MACHINE_QC".equals(connectionType)) {
            perpendicularityInput.setVisibility(View.VISIBLE);
            perpendicularityLabel.setVisibility(View.VISIBLE);
            lengthFEInput.setVisibility(View.VISIBLE);
            lengthFELabel.setVisibility(View.VISIBLE);
            chamferLengthInput.setVisibility(View.VISIBLE);
            chamferLengthLabel.setVisibility(View.VISIBLE);
            angleInput.setVisibility(View.VISIBLE);
            angleLabel.setVisibility(View.VISIBLE);
        }
    }

    private void validateAndSubmit() {
        boolean allCorrect = true;
        resetInputColors();

        allCorrect &= checkRange(flangeOuterDiaInput, 200.75, 201.25);
        allCorrect &= checkRange(flangeThicknessInput, 12.00, 13.00);
        allCorrect &= checkRange(outerCollarDiaInput, 148.60, 149.40);
        allCorrect &= checkRange(radiusInput, 1.20, 1.50);
        allCorrect &= checkRange(surfaceRoughnessInput, 4.0, 4.0);

        if ("MACHINE_QC".equals(connectionType)) {
            allCorrect &= checkRange(perpendicularityInput, 0.0, 0.25);
            allCorrect &= checkRange(lengthFEInput, 2.50, 3.50);
            allCorrect &= checkRange(chamferLengthInput, 2.50, 3.50);
            allCorrect &= checkRange(angleInput, 44.5, 45.5);
        }

        if (allCorrect) {
            submitMessage.setTextColor(Color.parseColor("#388E3C"));
            submitMessage.setText("All dimensions correct! Measurements submitted.");
            disableInputs();
        } else {
            submitMessage.setTextColor(Color.parseColor("#D32F2F"));
            submitMessage.setText("Some dimensions are incorrect! Check highlighted fields.");
        }

        // ✅ Save entered values to history
        saveToHistory();
    }

    private void resetInputColors() {
        EditText[] allInputs = {flangeOuterDiaInput, flangeThicknessInput, outerCollarDiaInput,
                radiusInput, surfaceRoughnessInput, perpendicularityInput, lengthFEInput,
                chamferLengthInput, angleInput};
        for (EditText e : allInputs) if (e != null) e.setBackgroundColor(Color.parseColor("#E0E0E0"));
    }

    private boolean checkRange(EditText input, double min, double max) {
        try {
            double value = Double.parseDouble(input.getText().toString());
            if (value < min || value > max) {
                input.setBackgroundColor(Color.parseColor("#B71C1C"));
                return false;
            }
        } catch (Exception e) {
            input.setBackgroundColor(Color.parseColor("#B71C1C"));
            return false;
        }
        return true;
    }

    private void disableInputs() {
        EditText[] allInputs = {flangeOuterDiaInput, flangeThicknessInput, outerCollarDiaInput,
                radiusInput, surfaceRoughnessInput, perpendicularityInput, lengthFEInput,
                chamferLengthInput, angleInput};
        for (EditText e : allInputs) if (e != null) e.setEnabled(false);
    }

    // ✅ Save current input values to MainActivity.dimensionHistory
    private void saveToHistory() {
        DimensionRecord record = new DimensionRecord(
                flangeOuterDiaInput.getText().toString(),
                flangeThicknessInput.getText().toString(),
                outerCollarDiaInput.getText().toString(),
                radiusInput.getText().toString(),
                surfaceRoughnessInput.getText().toString(),
                perpendicularityInput.getText().toString(),
                lengthFEInput.getText().toString(),
                chamferLengthInput.getText().toString(),
                angleInput.getText().toString()
        );
        MainActivity.dimensionHistory.add(record);
    }

    // Method to change connection type dynamically
    public void setConnectionType(String type) {
        this.connectionType = type;
        updateDimensionVisibility();
    }
}
