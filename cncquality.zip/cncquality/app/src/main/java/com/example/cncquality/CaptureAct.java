package com.example.cncquality;

import com.journeyapps.barcodescanner.CaptureActivity;

/**
 * Empty class that simply extends ZXing's CaptureActivity.
 * Make sure the package name here matches the manifest package.
 */
public class CaptureAct extends CaptureActivity {
    // No custom code needed
}
