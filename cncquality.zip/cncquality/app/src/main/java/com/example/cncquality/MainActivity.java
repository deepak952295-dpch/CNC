package com.example.cncquality;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.PopupMenu;
import android.view.MenuItem;

import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AppCompatActivity;

import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    TextView machineBox, operatorBox, qpBox;
    Button settingsBtn, scanMachineBtn, scanOperatorBtn, scanQPBtn, nextBtn;

    String currentScanTarget = ""; // To track which button was clicked

    private boolean machineConnected = false;
    private boolean operatorConnected = false;
    private boolean qpConnected = false;

    // ✅ Shared history
    public static ArrayList<DimensionRecord> dimensionHistory = new ArrayList<>();

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        machineBox = findViewById(R.id.machineBox);
        operatorBox = findViewById(R.id.operatorBox);
        qpBox = findViewById(R.id.qpBox);
        settingsBtn = findViewById(R.id.settingsBtn);
        scanMachineBtn = findViewById(R.id.scanMachineBtn);
        scanOperatorBtn = findViewById(R.id.scanOperatorBtn);
        scanQPBtn = findViewById(R.id.scanQPBtn);
        nextBtn = findViewById(R.id.nextBtn);

        nextBtn.setVisibility(Button.GONE);

        scanMachineBtn.setOnClickListener(v -> {
            currentScanTarget = "MACHINE";
            scanCode();
        });

        scanOperatorBtn.setOnClickListener(v -> {
            currentScanTarget = "OPERATOR";
            scanCode();
        });

        scanQPBtn.setOnClickListener(v -> {
            currentScanTarget = "QP";
            scanCode();
        });

        nextBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, MeasurementActivity.class);

            if (machineConnected && operatorConnected) {
                intent.putExtra("mode", "ALL");
            } else if (machineConnected && qpConnected) {
                intent.putExtra("mode", "LIMITED");
            }

            startActivity(intent);
        });

        settingsBtn.setOnClickListener(v -> {
            PopupMenu popup = new PopupMenu(MainActivity.this, v);
            popup.getMenu().add("Logout");
            popup.setOnMenuItemClickListener(item -> {
                if (item.getTitle().equals("Logout")) {
                    resetConnections();
                }
                return true;
            });
            popup.show();
        });
    }

    private void scanCode() {
        ScanOptions options = new ScanOptions();
        options.setPrompt("Scan a QR code");
        options.setBeepEnabled(true);
        options.setOrientationLocked(true);
        options.setCaptureActivity(CaptureAct.class);
        barcodeLauncher.launch(options);
    }

    private final ActivityResultLauncher<ScanOptions> barcodeLauncher =
            registerForActivityResult(new ScanContract(), result -> {
                if (result.getContents() != null) {
                    String scannedText = result.getContents();

                    switch (currentScanTarget) {
                        case "MACHINE":
                            machineBox.setText("Machine\n" + scannedText);
                            machineBox.setTextColor(Color.GREEN);
                            machineConnected = true;
                            break;

                        case "OPERATOR":
                            operatorBox.setText("Operator\n" + scannedText);
                            operatorBox.setTextColor(Color.GREEN);
                            operatorConnected = true;
                            break;

                        case "QP":
                            qpBox.setText("QP\n" + scannedText);
                            qpBox.setTextColor(Color.GREEN);
                            qpConnected = true;
                            break;
                    }

                    checkNextButtonVisibility();
                }
            });

    private void resetConnections() {
        machineBox.setText("Machine\nNot Connected");
        operatorBox.setText("Operator\nNot Connected");
        qpBox.setText("QP\nNot Connected");

        int defaultColor = getResources().getColor(android.R.color.black);
        machineBox.setTextColor(defaultColor);
        operatorBox.setTextColor(defaultColor);
        qpBox.setTextColor(defaultColor);

        machineConnected = false;
        operatorConnected = false;
        qpConnected = false;

        nextBtn.setVisibility(Button.GONE);
    }

    private void checkNextButtonVisibility() {
        if ((machineConnected && operatorConnected) || (machineConnected && qpConnected)) {
            nextBtn.setVisibility(Button.VISIBLE);
        }
    }
}
