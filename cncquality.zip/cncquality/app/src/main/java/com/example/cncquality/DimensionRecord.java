package com.example.cncquality;

public class DimensionRecord {

    public String flangeOuterDia, flangeThickness, outerCollarDia, radius, surfaceRoughness,
            perpendicularity, lengthFE, chamferLength, angle;

    public DimensionRecord(String flangeOuterDia, String flangeThickness, String outerCollarDia,
                           String radius, String surfaceRoughness, String perpendicularity,
                           String lengthFE, String chamferLength, String angle) {
        this.flangeOuterDia = flangeOuterDia;
        this.flangeThickness = flangeThickness;
        this.outerCollarDia = outerCollarDia;
        this.radius = radius;
        this.surfaceRoughness = surfaceRoughness;
        this.perpendicularity = perpendicularity;
        this.lengthFE = lengthFE;
        this.chamferLength = chamferLength;
        this.angle = angle;
    }
}
