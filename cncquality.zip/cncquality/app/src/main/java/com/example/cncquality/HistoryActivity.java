package com.example.cncquality;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class HistoryActivity extends AppCompatActivity {

    ListView historyListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        historyListView = findViewById(R.id.historyListView);

        // Access the history from MeasurementActivity
        ArrayList<DimensionRecord> history = MainActivity.dimensionHistory;

        ArrayList<String> displayList = new ArrayList<>();
        for (DimensionRecord record : history) {
            displayList.add(record.toString());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, displayList);
        historyListView.setAdapter(adapter);
    }
}
